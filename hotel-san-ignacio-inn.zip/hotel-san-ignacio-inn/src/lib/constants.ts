export const WHATSAPP_LINK =
  "https://wa.me/528712681366?text=Hola%2C%20quiero%20consultar%20disponibilidad%20para%20reservar%20en%20Hotel%20San%20Ignacio%20Inn"

export const WHATSAPP_NUMBER = "+52 871 268 1366"

export const MAPS_LINK =
  "https://www.google.com/maps/search/Carretera+Santa+Fe,+Roberto+Fierro+Km+75,+Ignacio+Allende,+27400+Torreón,+Coah.,+México"

export const ADDRESS =
  "Carretera Santa Fe, Roberto Fierro Km 75, Ignacio Allende, 27400 Torreón, Coahuila, México"

export const HOTEL_NAME = "Hotel San Ignacio Inn"
