import { MAPS_LINK, ADDRESS } from '@/lib/constants'

export default function Location() {
  return (
    <section id="ubicacion" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Info */}
          <div>
            <p className="section-subtitle">Cómo llegarnos</p>
            <h2 className="section-title mb-4">
              Fácil de encontrar,
              <span className="block text-navy-500"> difícil de olvidar</span>
            </h2>
            <div className="w-16 h-0.5 bg-gold-500 mt-4 mb-6" />

            <p className="text-navy-500 leading-relaxed mb-6">
              Ubicado sobre Carretera Santa Fe, con acceso práctico para viajeros de paso,
              trabajo o estancia corta en Torreón. Llegas, estacionas y entras. Sin complicaciones.
            </p>

            {/* Address block */}
            <div className="bg-sand-50 border border-sand-200 rounded-2xl p-5 mb-6">
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-xl bg-navy-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <LocationIcon />
                </div>
                <div>
                  <p className="font-semibold text-navy-800 mb-1">Dirección</p>
                  <p className="text-navy-500 text-sm leading-relaxed">{ADDRESS}</p>
                </div>
              </div>
            </div>

            {/* Access tips */}
            <div className="space-y-3 mb-8">
              {[
                'Acceso directo desde Carretera Santa Fe (Roberto Fierro)',
                'A minutos de la zona industrial y centro de Torreón',
                'Amplio estacionamiento para autos y camionetas',
                'Señalización visible desde la carretera',
              ].map((tip) => (
                <div key={tip} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-gold-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <svg className="w-3 h-3 text-gold-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3}>
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                  </div>
                  <p className="text-navy-500 text-sm">{tip}</p>
                </div>
              ))}
            </div>

            <a
              href={MAPS_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary inline-flex"
            >
              <MapIcon />
              Abrir en Google Maps
            </a>
          </div>

          {/* Right: Map visual */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl border border-sand-200 aspect-[4/3]">
              {/* Stylized map placeholder */}
              <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 relative flex items-center justify-center">
                {/* Road grid */}
                <MapIllustration />

                {/* Pin */}
                <div className="absolute inset-0 flex items-center justify-center z-10">
                  <div className="flex flex-col items-center">
                    <div className="bg-red-500 w-10 h-10 rounded-full flex items-center justify-center shadow-xl border-4 border-white">
                      <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                      </svg>
                    </div>
                    <div className="bg-white shadow-lg rounded-xl px-4 py-2 mt-2 text-center">
                      <p className="font-semibold text-navy-800 text-sm">Hotel San Ignacio Inn</p>
                      <p className="text-navy-400 text-xs">Km 75, Carretera Santa Fe</p>
                    </div>
                    <div className="w-0.5 h-4 bg-red-500 -mt-2 -z-10" />
                  </div>
                </div>
              </div>
            </div>

            {/* Overlay button */}
            <a
              href={MAPS_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute bottom-4 right-4 bg-white shadow-xl rounded-xl px-4 py-2.5 flex items-center gap-2 hover:bg-sand-50 transition-colors"
            >
              <svg className="w-4 h-4 text-navy-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M15 3h6v6" />
                <path d="M10 14L21 3" />
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6" />
              </svg>
              <span className="text-navy-700 font-semibold text-sm">Ver en Maps</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

function MapIllustration() {
  return (
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="300" fill="#e8eaed" />

      {/* Blocks */}
      <rect x="20" y="20" width="100" height="60" rx="3" fill="#d1d5db" />
      <rect x="140" y="20" width="80" height="60" rx="3" fill="#d1d5db" />
      <rect x="240" y="20" width="140" height="60" rx="3" fill="#d1d5db" />

      <rect x="20" y="120" width="60" height="80" rx="3" fill="#d1d5db" />
      <rect x="100" y="120" width="120" height="80" rx="3" fill="#d1d5db" />
      <rect x="240" y="120" width="140" height="80" rx="3" fill="#d1d5db" />

      <rect x="20" y="230" width="160" height="50" rx="3" fill="#d1d5db" />
      <rect x="200" y="230" width="180" height="50" rx="3" fill="#d1d5db" />

      {/* Main road (horizontal) */}
      <rect x="0" y="95" width="400" height="18" fill="#c8cacc" />
      <rect x="0" y="103" width="400" height="2" fill="white" strokeDasharray="20 10" />

      {/* Main road (vertical) */}
      <rect x="220" y="0" width="16" height="300" fill="#c8cacc" />
      <rect x="228" y="0" width="2" height="300" fill="white" />

      {/* Secondary roads */}
      <rect x="0" y="205" width="400" height="12" fill="#cccfd1" />
      <rect x="85" y="0" width="10" height="300" fill="#cccfd1" />

      {/* Green areas */}
      <rect x="130" y="130" width="60" height="50" rx="4" fill="#c6d9b0" />
    </svg>
  )
}

function LocationIcon() {
  return (
    <svg className="w-5 h-5 text-navy-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}

function MapIcon() {
  return (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}
