const testimonials = [
  {
    name: 'Roberto Hernández',
    origin: 'Monterrey, N.L.',
    role: 'Viajero de negocios',
    rating: 5,
    text: 'Llevo tres viajes a Torreón y siempre vuelvo al San Ignacio. El cuarto siempre limpio, la cama cómoda y el desayuno del restaurante es casero. Nada que envidiarle a hoteles más caros.',
    avatar: 'R',
    color: 'bg-navy-700',
  },
  {
    name: 'Claudia Morales',
    origin: 'Ciudad de México',
    role: 'Viajera frecuente',
    rating: 5,
    text: 'Me sorprendió la atención. Llegué tarde por retraso en carretera y me esperaron sin problema. La habitación estaba en perfectas condiciones. El WiFi funcionó todo el tiempo, cosa que valoro mucho.',
    avatar: 'C',
    color: 'bg-gold-500',
  },
  {
    name: 'Familia Garza Salas',
    origin: 'Saltillo, Coah.',
    role: 'Viaje familiar',
    rating: 4,
    text: 'Muy buena opción para una familia. La habitación familiar nos dio espacio para todos. Los niños disfrutaron la alberca. El estacionamiento es amplio, fundamental cuando viajas en auto con equipaje.',
    avatar: 'G',
    color: 'bg-sand-500',
  },
]

export default function Testimonials() {
  return (
    <section className="py-20 bg-warm-gradient">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="section-subtitle">Opiniones reales</p>
          <h2 className="section-title">
            Lo que dicen
            <span className="block text-navy-500"> nuestros huéspedes</span>
          </h2>
          <div className="divider-gold" />
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-6 shadow-sm border border-sand-200 card-hover flex flex-col"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, si) => (
                  <svg
                    key={si}
                    className={`w-4 h-4 ${si < t.rating ? 'text-gold-500' : 'text-sand-300'}`}
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                ))}
              </div>

              {/* Quote */}
              <p className="text-navy-600 text-sm leading-relaxed mb-6 flex-1 italic">
                &ldquo;{t.text}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-sand-100">
                <div
                  className={`w-10 h-10 rounded-full ${t.color} flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}
                >
                  {t.avatar}
                </div>
                <div>
                  <p className="font-semibold text-navy-800 text-sm">{t.name}</p>
                  <p className="text-navy-400 text-xs">
                    {t.role} · {t.origin}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust strip */}
        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-8 py-8 border-y border-sand-200">
          {[
            { value: '4.5★', label: 'Calificación promedio' },
            { value: '1,000+', label: 'Huéspedes atendidos' },
            { value: '100%', label: 'Reservas confirmadas' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display text-3xl text-navy-800 font-bold">{stat.value}</p>
              <p className="text-navy-400 text-sm mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
