import { WHATSAPP_LINK } from '@/lib/constants'

const rooms = [
  {
    type: 'Sencilla',
    badge: 'Más popular',
    badgeColor: 'bg-navy-700 text-white',
    desc: 'Perfecta para el viajero solo o ejecutivo de paso. Espaciosa, funcional y con todo lo esencial para un descanso productivo.',
    amenities: ['Cama matrimonial', 'TV', 'A/C y calefacción', 'Baño privado', 'WiFi', 'Escritorio de trabajo'],
    highlight: false,
    gradient: 'from-navy-50 to-sand-100',
    iconBg: 'bg-navy-100',
    iconColor: 'text-navy-700',
  },
  {
    type: 'Doble',
    badge: 'Recomendada',
    badgeColor: 'bg-gold-500 text-navy-900',
    desc: 'Ideal para parejas o dos compañeros de viaje. Dos camas individuales o cama king, con espacio amplio para moverse con comodidad.',
    amenities: ['2 camas individuales o king', 'TV pantalla plana', 'A/C y calefacción', 'Baño privado', 'WiFi', 'Cafetera'],
    highlight: true,
    gradient: 'from-navy-700 to-navy-900',
    iconBg: 'bg-white/20',
    iconColor: 'text-gold-300',
  },
  {
    type: 'Familiar',
    badge: 'Más espacio',
    badgeColor: 'bg-sand-400 text-white',
    desc: 'La opción ideal cuando viajan niños o el grupo es más grande. Espacio generoso, dos ambientes bien distribuidos y todas las comodidades.',
    amenities: ['Cama matrimonial + literas', 'TV', 'A/C y calefacción', 'Baño completo', 'WiFi', 'Área de estar'],
    highlight: false,
    gradient: 'from-sand-50 to-amber-50',
    iconBg: 'bg-amber-100',
    iconColor: 'text-amber-700',
  },
]

export default function Rooms() {
  return (
    <section id="habitaciones" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="section-subtitle">Nuestras habitaciones</p>
          <h2 className="section-title">
            Elige la estancia
            <span className="block text-navy-500"> que mejor se adapta a ti</span>
          </h2>
          <div className="divider-gold" />
          <p className="text-navy-500 max-w-xl mx-auto text-base leading-relaxed">
            Todas las habitaciones incluyen WiFi, estacionamiento y acceso a alberca.
            Reserva directo por WhatsApp para confirmar disponibilidad al instante.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {rooms.map((room, i) => (
            <div
              key={i}
              className={`relative rounded-2xl overflow-hidden card-hover ${
                room.highlight ? 'ring-2 ring-gold-500 shadow-2xl scale-[1.02]' : 'border border-sand-200 shadow-sm'
              }`}
            >
              {/* Top visual */}
              <div className={`bg-gradient-to-br ${room.gradient} p-8 relative`}>
                {/* Badge */}
                <span className={`${room.badgeColor} text-xs font-bold px-3 py-1 rounded-full`}>
                  {room.badge}
                </span>

                {/* Room illustration */}
                <div className="mt-6 flex justify-center">
                  <RoomIllustration highlight={room.highlight} iconBg={room.iconBg} iconColor={room.iconColor} type={room.type} />
                </div>
              </div>

              {/* Content */}
              <div className={`p-6 ${room.highlight ? 'bg-navy-800' : 'bg-white'}`}>
                <h3 className={`font-display text-2xl mb-2 ${room.highlight ? 'text-white' : 'text-navy-800'}`}>
                  Habitación {room.type}
                </h3>
                <p className={`text-sm leading-relaxed mb-5 ${room.highlight ? 'text-white/70' : 'text-navy-500'}`}>
                  {room.desc}
                </p>

                {/* Amenities */}
                <ul className="space-y-2 mb-6">
                  {room.amenities.map((a) => (
                    <li key={a} className="flex items-center gap-2">
                      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${room.highlight ? 'bg-gold-400' : 'bg-navy-400'}`} />
                      <span className={`text-sm ${room.highlight ? 'text-white/80' : 'text-navy-600'}`}>{a}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-full font-semibold text-sm transition-all duration-200 hover:-translate-y-0.5 ${
                    room.highlight
                      ? 'bg-green-500 hover:bg-green-400 text-white shadow-lg shadow-green-500/30'
                      : 'bg-navy-700 hover:bg-navy-800 text-white'
                  }`}
                >
                  <WhatsAppIcon />
                  Consultar disponibilidad
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom note */}
        <p className="text-center text-navy-400 text-sm mt-8">
          ¿Grupo grande o necesidades especiales?{' '}
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="text-navy-700 font-semibold underline underline-offset-2 hover:text-gold-600 transition-colors"
          >
            Escríbenos y te asesoramos sin compromiso.
          </a>
        </p>
      </div>
    </section>
  )
}

function RoomIllustration({ highlight, iconBg, iconColor, type }: {
  highlight: boolean
  iconBg: string
  iconColor: string
  type: string
}) {
  return (
    <div className={`w-24 h-24 rounded-2xl ${iconBg} flex items-center justify-center`}>
      {type === 'Sencilla' && (
        <svg className={`w-12 h-12 ${iconColor}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
          <path d="M2 4v16M2 8h18a2 2 0 012 2v6H2M2 12h20" />
          <path d="M6 8V4" />
          <rect x="6" y="4" width="7" height="4" rx="1" />
        </svg>
      )}
      {type === 'Doble' && (
        <svg className={`w-12 h-12 ${iconColor}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
          <path d="M2 4v16M2 8h18a2 2 0 012 2v6H2M2 12h20" />
          <path d="M6 8V4" />
          <rect x="5" y="4" width="5" height="4" rx="1" />
          <rect x="12" y="4" width="5" height="4" rx="1" />
        </svg>
      )}
      {type === 'Familiar' && (
        <svg className={`w-12 h-12 ${iconColor}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
          <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M23 21v-2a4 4 0 00-3-3.87" />
          <path d="M16 3.13a4 4 0 010 7.75" />
        </svg>
      )}
    </div>
  )
}

function WhatsAppIcon() {
  return (
    <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}
