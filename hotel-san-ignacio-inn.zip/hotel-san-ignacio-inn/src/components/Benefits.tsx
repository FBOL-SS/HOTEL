const benefits = [
  {
    icon: <BedIcon />,
    title: 'Habitaciones cómodas',
    desc: 'Espacios limpios, bien iluminados y con todo lo necesario para un descanso reparador.',
    color: 'bg-navy-50',
    accent: 'text-navy-700',
  },
  {
    icon: <RestaurantIcon />,
    title: 'Restaurante propio',
    desc: 'Desayuno y comida disponibles sin salir del hotel. Cocina sencilla y reconfortante.',
    color: 'bg-amber-50',
    accent: 'text-amber-700',
  },
  {
    icon: <PoolIcon />,
    title: 'Alberca',
    desc: 'Relájate después de un largo viaje en nuestra alberca disponible para todos los huéspedes.',
    color: 'bg-sky-50',
    accent: 'text-sky-700',
  },
  {
    icon: <WifiIcon />,
    title: 'WiFi sin costo',
    desc: 'Conectividad en todo el hotel para que sigas trabajando o navegando sin interrupciones.',
    color: 'bg-violet-50',
    accent: 'text-violet-700',
  },
  {
    icon: <ParkingIcon />,
    title: 'Estacionamiento',
    desc: 'Amplio estacionamiento dentro del hotel. Ideal para viajeros en auto o transporte propio.',
    color: 'bg-green-50',
    accent: 'text-green-700',
  },
  {
    icon: <LocationIcon />,
    title: 'Ubicación práctica',
    desc: 'Sobre Carretera Santa Fe km 75, con acceso rápido a vías principales de Torreón.',
    color: 'bg-orange-50',
    accent: 'text-orange-700',
  },
]

export default function Benefits() {
  return (
    <section className="py-20 bg-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="section-subtitle">Por qué elegirnos</p>
          <h2 className="section-title">
            Todo lo que necesitas
            <span className="block text-navy-500"> en un solo lugar</span>
          </h2>
          <div className="divider-gold" />
          <p className="text-navy-500 max-w-xl mx-auto text-base leading-relaxed">
            Pensado para el viajero práctico. Sin complicaciones, sin cobros sorpresa.
            Solo comodidad y buena atención desde que llegas.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((item, i) => (
            <div
              key={i}
              className={`${item.color} rounded-2xl p-6 card-hover border border-transparent hover:border-sand-200`}
            >
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${item.color} shadow-sm border border-white`}
              >
                <span className={item.accent}>{item.icon}</span>
              </div>
              <h3 className="font-display text-lg text-navy-800 mb-2">{item.title}</h3>
              <p className="text-navy-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function BedIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M2 4v16M2 8h18a2 2 0 012 2v6H2M2 12h20" />
      <path d="M6 8V4" />
      <rect x="6" y="4" width="5" height="4" rx="1" />
      <rect x="13" y="4" width="5" height="4" rx="1" />
    </svg>
  )
}

function RestaurantIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 002-2V2" />
      <path d="M7 2v20" />
      <path d="M21 15V2v0a5 5 0 00-5 5v6h5zm0 0v7" />
    </svg>
  )
}

function PoolIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M2 12h20" />
      <path d="M2 17c3.33 3.33 7.67 3.33 10 0s6.67-3.33 10 0" />
      <path d="M7 12V8a2 2 0 014 0v4" />
      <path d="M13 12V8a2 2 0 014 0v4" />
    </svg>
  )
}

function WifiIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M5 12.55a11 11 0 0114.08 0" />
      <path d="M1.42 9a16 16 0 0121.16 0" />
      <path d="M8.53 16.11a6 6 0 016.95 0" />
      <circle cx="12" cy="20" r="1" fill="currentColor" />
    </svg>
  )
}

function ParkingIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M9 17V7h4a3 3 0 010 6H9" />
    </svg>
  )
}

function LocationIcon() {
  return (
    <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}
