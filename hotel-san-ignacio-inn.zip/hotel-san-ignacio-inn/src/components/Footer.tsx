import { WHATSAPP_LINK, WHATSAPP_NUMBER, ADDRESS, MAPS_LINK, HOTEL_NAME } from '@/lib/constants'

const quickLinks = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Habitaciones', href: '#habitaciones' },
  { label: 'Servicios', href: '#servicios' },
  { label: 'Ubicación', href: '#ubicacion' },
]

export default function Footer() {
  return (
    <footer className="bg-navy-950 text-white">
      {/* Main footer */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="mb-4">
              <p className="font-display text-2xl font-bold text-white">Hotel San Ignacio</p>
              <p className="text-gold-400 text-sm tracking-[0.2em] uppercase mt-0.5">Inn · Torreón</p>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-6 max-w-sm">
              Hospedaje práctico y confortable en Torreón, Coahuila. Atendemos viajeros de negocios,
              familias y turistas desde hace años con el mismo compromiso: que descanses bien.
            </p>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-400 text-white font-semibold px-5 py-2.5 rounded-full transition-colors text-sm"
            >
              <WhatsAppIcon />
              Reservar por WhatsApp
            </a>
          </div>

          {/* Quick links */}
          <div>
            <p className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Navegación
            </p>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-white/50 hover:text-gold-400 transition-colors text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Contacto
            </p>
            <ul className="space-y-3">
              <li>
                <a
                  href={MAPS_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex gap-2 text-white/50 hover:text-white/80 transition-colors text-sm"
                >
                  <svg className="w-4 h-4 flex-shrink-0 mt-0.5 text-gold-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                  <span>{ADDRESS}</span>
                </a>
              </li>
              <li>
                <a
                  href={`tel:${WHATSAPP_NUMBER.replace(/\s/g, '')}`}
                  className="flex items-center gap-2 text-white/50 hover:text-white/80 transition-colors text-sm"
                >
                  <svg className="w-4 h-4 flex-shrink-0 text-gold-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                    <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 8.81a19.79 19.79 0 01-3.07-8.63A2 2 0 012 0h3a2 2 0 012 1.72c.127 1.07.36 2.12.69 3.14a2 2 0 01-.45 2.11L6.09 8.1a16 16 0 006.81 6.81l1.13-1.15a2 2 0 012.11-.45c1.02.33 2.07.56 3.14.69A2 2 0 0122 16.92z" />
                  </svg>
                  {WHATSAPP_NUMBER}
                </a>
              </li>
              <li>
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-white/50 hover:text-green-400 transition-colors text-sm"
                >
                  <WhatsAppIcon />
                  WhatsApp directo
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/30 text-xs">
            © {new Date().getFullYear()} {HOTEL_NAME}. Todos los derechos reservados.
          </p>
          <p className="text-white/30 text-xs">
            Torreón, Coahuila, México · Reservas directas vía WhatsApp
          </p>
        </div>
      </div>
    </footer>
  )
}

function WhatsAppIcon() {
  return (
    <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}
