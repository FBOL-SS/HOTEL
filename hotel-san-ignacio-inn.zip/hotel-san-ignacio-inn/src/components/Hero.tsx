import { WHATSAPP_LINK, MAPS_LINK } from '@/lib/constants'

export default function Hero() {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center overflow-hidden bg-hero-pattern hero-lines"
    >
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Large circle accent */}
        <div className="absolute -top-32 -right-32 w-[500px] h-[500px] rounded-full border border-white/5" />
        <div className="absolute -top-16 -right-16 w-[380px] h-[380px] rounded-full border border-white/5" />
        {/* Bottom left glow */}
        <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-navy-600/20 blur-3xl" />
        {/* Gold accent line */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-gold-500/40 to-transparent hidden lg:block" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-28 pb-20 lg:py-0 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Content */}
          <div>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-white/80 text-xs tracking-wide font-medium">
                Disponibilidad inmediata · Reserva directo
              </span>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl text-white leading-tight mb-6">
              Descansa
              <span className="block text-gold-300"> cómodo en </span>
              Torreón
            </h1>

            <p className="text-white/70 text-lg leading-relaxed mb-8 max-w-lg font-light">
              Hotel San Ignacio Inn te ofrece una estancia práctica, cómoda y bien
              ubicada cerca de las principales vías de acceso de Torreón. Ideal
              para viajeros de paso, negocios o descanso familiar.
            </p>

            {/* Trust signals */}
            <div className="flex flex-wrap gap-4 mb-10">
              {[
                { icon: '✓', text: 'WiFi sin costo' },
                { icon: '✓', text: 'Estacionamiento incluido' },
                { icon: '✓', text: 'Restaurante en hotel' },
                { icon: '✓', text: 'Alberca' },
              ].map((item) => (
                <span
                  key={item.text}
                  className="flex items-center gap-1.5 text-white/70 text-sm"
                >
                  <span className="text-gold-400 font-bold">{item.icon}</span>
                  {item.text}
                </span>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href={WHATSAPP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp text-base py-4 px-8 wa-pulse"
              >
                <WhatsAppIcon />
                Reservar por WhatsApp
              </a>
              <a href={MAPS_LINK} target="_blank" rel="noopener noreferrer" className="btn-outline-white text-base py-4 px-8">
                <MapIcon />
                Ver ubicación
              </a>
            </div>
          </div>

          {/* Right: Visual card */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Main card */}
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 relative">
                {/* Hotel illustration with gradients */}
                <div className="aspect-[4/3] rounded-xl overflow-hidden bg-gradient-to-br from-navy-600 to-navy-900 flex items-center justify-center relative">
                  {/* Building silhouette */}
                  <div className="absolute inset-0 flex items-end justify-center pb-0">
                    <BuildingIllustration />
                  </div>
                  {/* Sky gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/60 via-transparent to-transparent" />
                  {/* Stars */}
                  {[...Array(12)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 bg-white rounded-full opacity-60"
                      style={{
                        top: `${Math.random() * 40 + 5}%`,
                        left: `${Math.random() * 90 + 5}%`,
                        width: i % 3 === 0 ? '2px' : '1px',
                        height: i % 3 === 0 ? '2px' : '1px',
                      }}
                    />
                  ))}
                  {/* Moon */}
                  <div className="absolute top-5 right-8 w-8 h-8 rounded-full bg-gold-300/80" />
                </div>

                {/* Info strip */}
                <div className="mt-6 flex justify-between items-center">
                  <div>
                    <p className="text-white font-display text-lg">Hotel San Ignacio Inn</p>
                    <p className="text-white/60 text-sm mt-0.5">Torreón, Coahuila · México</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-gold-300 mb-1">
                      {[...Array(4)].map((_, i) => (
                        <StarIcon key={i} />
                      ))}
                    </div>
                    <p className="text-white/60 text-xs">Excelente reputación</p>
                  </div>
                </div>
              </div>

              {/* Floating availability badge */}
              <div className="absolute -top-4 -right-4 bg-green-500 text-white rounded-xl px-4 py-2 shadow-xl text-sm font-semibold">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                  Disponible hoy
                </div>
              </div>

              {/* Floating speed badge */}
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl px-4 py-2.5 shadow-xl">
                <p className="text-navy-800 text-xs font-bold">⚡ Respuesta rápida</p>
                <p className="text-navy-500 text-xs">Confirmación en minutos</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" preserveAspectRatio="none" className="w-full h-12 fill-cream">
          <path d="M0,40 C360,80 1080,0 1440,40 L1440,60 L0,60 Z" />
        </svg>
      </div>
    </section>
  )
}

function WhatsAppIcon() {
  return (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}

function MapIcon() {
  return (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}

function StarIcon() {
  return (
    <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  )
}

function BuildingIllustration() {
  return (
    <svg viewBox="0 0 400 220" className="w-full" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Ground */}
      <rect x="0" y="200" width="400" height="20" fill="rgba(255,255,255,0.05)" />

      {/* Main building */}
      <rect x="80" y="60" width="240" height="140" fill="rgba(255,255,255,0.08)" />
      <rect x="80" y="60" width="240" height="140" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />

      {/* Roof */}
      <polygon points="70,60 200,20 330,60" fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />

      {/* Sign */}
      <rect x="130" y="75" width="140" height="28" rx="3" fill="rgba(212,168,50,0.25)" stroke="rgba(212,168,50,0.5)" strokeWidth="1" />
      <text x="200" y="94" textAnchor="middle" fill="rgba(240,208,128,0.9)" fontSize="11" fontFamily="serif">San Ignacio Inn</text>

      {/* Windows row 1 */}
      {[110, 160, 210, 260].map((x) => (
        <rect key={x} x={x} y="120" width="28" height="22" rx="2" fill="rgba(255,220,100,0.2)" stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" />
      ))}

      {/* Windows row 2 */}
      {[110, 160, 210, 260].map((x) => (
        <rect key={x} x={x} y="158" width="28" height="22" rx="2" fill="rgba(255,220,100,0.15)" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
      ))}

      {/* Door */}
      <rect x="173" y="165" width="54" height="35" rx="3" fill="rgba(212,168,50,0.2)" stroke="rgba(255,255,255,0.2)" strokeWidth="0.5" />

      {/* Road */}
      <rect x="0" y="200" width="400" height="20" fill="rgba(0,0,0,0.3)" />
      <rect x="150" y="207" width="40" height="3" rx="1.5" fill="rgba(255,255,255,0.2)" />
      <rect x="210" y="207" width="40" height="3" rx="1.5" fill="rgba(255,255,255,0.2)" />

      {/* Tree left */}
      <rect x="40" y="170" width="5" height="30" fill="rgba(255,255,255,0.1)" />
      <ellipse cx="42" cy="155" rx="16" ry="20" fill="rgba(255,255,255,0.06)" />

      {/* Tree right */}
      <rect x="355" y="170" width="5" height="30" fill="rgba(255,255,255,0.1)" />
      <ellipse cx="357" cy="155" rx="16" ry="20" fill="rgba(255,255,255,0.06)" />
    </svg>
  )
}
