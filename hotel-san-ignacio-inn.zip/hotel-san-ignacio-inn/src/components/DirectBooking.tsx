import { WHATSAPP_LINK } from '@/lib/constants'

const reasons = [
  {
    icon: '💬',
    title: 'Atención personalizada',
    desc: 'Hablas directamente con el hotel, no con un sistema automatizado. Respondemos tus dudas al momento.',
  },
  {
    icon: '📅',
    title: 'Disponibilidad en tiempo real',
    desc: 'Sin intermediarios que retrasen la confirmación. Sabes al instante si hay cuarto para tus fechas.',
  },
  {
    icon: '💰',
    title: 'Sin comisiones extra',
    desc: 'Al reservar directo evitas los recargos de plataformas. El precio que ves es el precio que pagas.',
  },
  {
    icon: '🔄',
    title: 'Flexibilidad real',
    desc: 'Cambios de fecha, llegada tardía o necesidades especiales. Todo se habla y se acuerda fácil.',
  },
]

export default function DirectBooking() {
  return (
    <section className="py-20 bg-gradient-to-br from-navy-800 via-navy-900 to-navy-950 relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full border border-white/5" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full border border-white/5" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-navy-700/20 blur-3xl pointer-events-none" />

      {/* Gold top border */}
      <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-gold-500 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="text-gold-400 uppercase tracking-widest text-sm font-semibold mb-3">
            Reserva directa
          </p>
          <h2 className="font-display text-3xl md:text-4xl text-white leading-tight mb-4">
            Reserva directo y
            <span className="text-gold-300"> ahórrate complicaciones</span>
          </h2>
          <div className="w-16 h-0.5 bg-gold-500 mx-auto mt-4 mb-6" />
          <p className="text-white/60 max-w-xl mx-auto leading-relaxed">
            No necesitas Booking ni Expedia. Un mensaje de WhatsApp es todo lo que
            se necesita para reservar tu habitación en Hotel San Ignacio Inn.
          </p>
        </div>

        {/* Reasons grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-14">
          {reasons.map((r, i) => (
            <div
              key={i}
              className="bg-white/5 border border-white/10 rounded-2xl p-6 flex gap-4 hover:bg-white/8 transition-colors"
            >
              <span className="text-3xl flex-shrink-0">{r.icon}</span>
              <div>
                <h3 className="text-white font-semibold mb-1">{r.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{r.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Big CTA */}
        <div className="text-center">
          <div className="inline-block bg-white/5 border border-white/10 rounded-2xl p-8 max-w-lg w-full">
            {/* Steps */}
            <div className="flex items-center justify-center gap-3 mb-6">
              {[
                { n: '1', label: 'Escríbenos' },
                { n: '→', label: '' },
                { n: '2', label: 'Confirmamos' },
                { n: '→', label: '' },
                { n: '3', label: '¡Listo!' },
              ].map((step, i) =>
                step.label ? (
                  <div key={i} className="text-center">
                    <div className="w-8 h-8 rounded-full bg-navy-600 border border-gold-500/40 flex items-center justify-center text-white text-sm font-bold mb-1">
                      {step.n}
                    </div>
                    <span className="text-white/50 text-xs">{step.label}</span>
                  </div>
                ) : (
                  <span key={i} className="text-gold-500/50 text-lg mt-[-16px]">{step.n}</span>
                )
              )}
            </div>

            <p className="text-white/60 text-sm mb-6">
              Proceso 100% por WhatsApp. Sin formularios complicados, sin esperas.
            </p>

            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp justify-center w-full py-4 text-base wa-pulse"
            >
              <WhatsAppIcon />
              Reservar ahora por WhatsApp
            </a>

            <p className="text-white/40 text-xs mt-4">
              Respuesta garantizada en horario de atención · Sin costo de contacto
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

function WhatsAppIcon() {
  return (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}
