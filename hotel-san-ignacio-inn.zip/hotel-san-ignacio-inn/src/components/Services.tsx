const services = [
  {
    icon: <RestaurantIcon />,
    label: 'Restaurante',
    desc: 'Desayuno, comida y cena disponibles',
  },
  {
    icon: <PoolIcon />,
    label: 'Alberca',
    desc: 'Acceso libre para huéspedes',
  },
  {
    icon: <WifiIcon />,
    label: 'WiFi incluido',
    desc: 'Cobertura en todo el hotel',
  },
  {
    icon: <ParkingIcon />,
    label: 'Estacionamiento',
    desc: 'Amplio y vigilado, sin costo',
  },
  {
    icon: <ReceptionIcon />,
    label: 'Recepción',
    desc: 'Atención personalizada',
  },
  {
    icon: <InvoiceIcon />,
    label: 'Facturación',
    desc: 'Factura fiscal disponible',
  },
  {
    icon: <AcIcon />,
    label: 'Climatización',
    desc: 'A/C y calefacción en todas las habitaciones',
  },
  {
    icon: <BusinessIcon />,
    label: 'Viajero de negocios',
    desc: 'Escritorio y conectividad garantizada',
  },
]

export default function Services() {
  return (
    <section id="servicios" className="py-20 bg-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="section-subtitle">Lo que ofrecemos</p>
          <h2 className="section-title">
            Servicios incluidos
            <span className="block text-navy-500"> en tu estancia</span>
          </h2>
          <div className="divider-gold" />
          <p className="text-navy-500 max-w-lg mx-auto text-base leading-relaxed">
            Sin cobros escondidos. Lo que ves es lo que recibes.
            Servicios pensados para que tu estadía sea lo más cómoda posible.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
          {services.map((s, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-5 text-center card-hover border border-sand-200 shadow-sm"
            >
              <div className="w-14 h-14 mx-auto mb-3 rounded-xl bg-navy-50 flex items-center justify-center text-navy-700">
                {s.icon}
              </div>
              <p className="font-semibold text-navy-800 text-sm mb-1">{s.label}</p>
              <p className="text-navy-400 text-xs leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>

        {/* Bottom strip */}
        <div className="mt-12 bg-navy-800 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <p className="font-display text-white text-xl mb-1">¿Necesitas algo más?</p>
            <p className="text-white/60 text-sm">Cuéntanos tus necesidades y las atendemos antes de tu llegada.</p>
          </div>
          <a
            href="https://wa.me/528712681366?text=Hola%2C%20tengo%20una%20pregunta%20sobre%20los%20servicios%20del%20Hotel%20San%20Ignacio%20Inn"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-whatsapp flex-shrink-0"
          >
            <WhatsAppIcon />
            Preguntar por WhatsApp
          </a>
        </div>
      </div>
    </section>
  )
}

function RestaurantIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 002-2V2" />
      <path d="M7 2v20" />
      <path d="M21 15V2v0a5 5 0 00-5 5v6h5zm0 0v7" />
    </svg>
  )
}

function PoolIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M2 12h20" />
      <path d="M2 17c3.33 3.33 7.67 3.33 10 0s6.67-3.33 10 0" />
      <path d="M7 12V8a2 2 0 014 0v4" />
      <path d="M13 12V8a2 2 0 014 0v4" />
    </svg>
  )
}

function WifiIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M5 12.55a11 11 0 0114.08 0" />
      <path d="M1.42 9a16 16 0 0121.16 0" />
      <path d="M8.53 16.11a6 6 0 016.95 0" />
      <circle cx="12" cy="20" r="1" fill="currentColor" />
    </svg>
  )
}

function ParkingIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M9 17V7h4a3 3 0 010 6H9" />
    </svg>
  )
}

function ReceptionIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

function InvoiceIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </svg>
  )
}

function AcIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="2" y="6" width="20" height="10" rx="2" />
      <path d="M7 16v2" />
      <path d="M12 16v2" />
      <path d="M17 16v2" />
      <path d="M7 11h10" />
    </svg>
  )
}

function BusinessIcon() {
  return (
    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
      <rect x="2" y="7" width="20" height="14" rx="2" />
      <path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16" />
    </svg>
  )
}

function WhatsAppIcon() {
  return (
    <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  )
}
