import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Hotel San Ignacio Inn | Torreón, Coahuila — Reserva Directo',
  description: 'Hotel cómodo y bien ubicado en Torreón, Coahuila. Habitaciones climatizadas, restaurante, alberca y estacionamiento. Reserva directo por WhatsApp y obtén atención personalizada.',
  keywords: 'hotel torreón, hotel coahuila, hotel carretera santa fe torreón, hotel económico torreón, hotel viajero torreón, san ignacio inn',
  openGraph: {
    title: 'Hotel San Ignacio Inn | Torreón, Coahuila',
    description: 'Descansa cómodo en Torreón. Habitaciones climatizadas, restaurante, alberca y estacionamiento. Reserva directo por WhatsApp.',
    type: 'website',
    locale: 'es_MX',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className="scroll-smooth">
      <body className="antialiased">{children}</body>
    </html>
  )
}
