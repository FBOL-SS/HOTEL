/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#f0f4f8',
          100: '#d9e4ed',
          200: '#b3c9db',
          300: '#7aa0bc',
          400: '#4a7a9e',
          500: '#2c5f82',
          600: '#1e4a6b',
          700: '#163854',
          800: '#0f2740',
          900: '#0a1929',
          950: '#06101a',
        },
        gold: {
          300: '#f0d080',
          400: '#e8c060',
          500: '#d4a832',
          600: '#b8901e',
        },
        sand: {
          50: '#faf8f5',
          100: '#f5f0e8',
          200: '#ede2d0',
          300: '#dfd0b4',
          400: '#ccb490',
          500: '#b8956a',
        },
        cream: '#fdfaf6',
      },
      fontFamily: {
        display: ['var(--font-playfair)', 'Georgia', 'serif'],
        body: ['var(--font-lato)', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'hero-pattern': "linear-gradient(135deg, #0a1929 0%, #163854 40%, #1e4a6b 70%, #0f2740 100%)",
        'warm-gradient': "linear-gradient(135deg, #fdfaf6 0%, #f5f0e8 100%)",
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease-out forwards',
        'fade-in': 'fadeIn 0.8s ease-out forwards',
        'slide-right': 'slideRight 0.6s ease-out forwards',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideRight: {
          '0%': { opacity: '0', transform: 'translateX(-20px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
}
