# 🏨 Hotel San Ignacio Inn — Landing Page

Landing page de reservas directas para **Hotel San Ignacio Inn**, Torreón, Coahuila.  
Construida con Next.js 14, React y Tailwind CSS. Lista para Vercel.

---

## 📁 Estructura de carpetas

```
hotel-san-ignacio-inn/
├── src/
│   ├── app/
│   │   ├── globals.css         # Estilos globales + Tailwind
│   │   ├── layout.tsx          # Layout raíz con metadata SEO
│   │   └── page.tsx            # Página principal (ensambla secciones)
│   ├── components/
│   │   ├── Header.tsx          # Encabezado fijo con menú responsive
│   │   ├── Hero.tsx            # Hero principal con CTA WhatsApp
│   │   ├── Benefits.tsx        # 6 tarjetas de beneficios
│   │   ├── Rooms.tsx           # 3 tipos de habitaciones
│   │   ├── DirectBooking.tsx   # Sección reserva directa vs plataformas
│   │   ├── Services.tsx        # Grid de servicios con íconos
│   │   ├── Location.tsx        # Mapa ilustrado + dirección
│   │   ├── Testimonials.tsx    # 3 reseñas + estadísticas
│   │   ├── FinalCTA.tsx        # CTA de cierre
│   │   ├── Footer.tsx          # Pie de página completo
│   │   └── WhatsAppFloat.tsx   # Botón flotante WhatsApp
│   └── lib/
│       └── constants.ts        # Datos del hotel (teléfono, dirección, links)
├── public/                     # Aquí van tus imágenes reales
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
├── tsconfig.json
├── package.json
└── .gitignore
```

---

## ⚙️ Instalación y ejecución local

```bash
# 1. Instalar dependencias
npm install

# 2. Arrancar en modo desarrollo
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

```bash
# Construir para producción
npm run build

# Vista previa de producción
npm start
```

---

## 🚀 Despliegue en GitHub + Vercel

### Paso 1: Subir a GitHub

```bash
# En la carpeta del proyecto:
git init
git add .
git commit -m "feat: landing page Hotel San Ignacio Inn"

# Crear repo en github.com, luego:
git remote add origin https://github.com/TU_USUARIO/hotel-san-ignacio-inn.git
git branch -M main
git push -u origin main
```

### Paso 2: Desplegar en Vercel

1. Ve a [vercel.com](https://vercel.com) e inicia sesión (puedes usar tu cuenta de GitHub)
2. Click en **"Add New Project"**
3. Selecciona el repositorio `hotel-san-ignacio-inn`
4. Vercel detecta Next.js automáticamente — **no cambies nada**
5. Click en **"Deploy"**
6. En ~2 minutos tienes tu URL: `https://hotel-san-ignacio-inn.vercel.app`

Para dominio personalizado (ej: `hotelsanignacioinn.com`), ve a **Settings → Domains** en tu proyecto de Vercel.

---

## 🎨 Personalización

### 📞 Cambiar teléfono / WhatsApp
Edita `src/lib/constants.ts`:
```ts
export const WHATSAPP_LINK = "https://wa.me/52TUNUMERO?text=..."
export const WHATSAPP_NUMBER = "+52 871 XXX XXXX"
```

### 🗺️ Cambiar enlace de Google Maps
En `src/lib/constants.ts`, actualiza `MAPS_LINK` con el enlace exacto desde Google Maps:
1. Busca el hotel en maps.google.com
2. Click en "Compartir" → "Copiar enlace"
3. Pega el enlace en `MAPS_LINK`

### 🖼️ Agregar imágenes reales
Coloca tus fotos en `/public/`:
```
public/
├── hero.jpg          # Foto principal (1920x1080 recomendado)
├── habitacion-sencilla.jpg
├── habitacion-doble.jpg
├── habitacion-familiar.jpg
├── restaurante.jpg
├── alberca.jpg
└── logo.png
```

Luego úsalas en los componentes con `<img src="/hero.jpg" alt="..." />` o con el componente `<Image>` de Next.js.

### 🎨 Cambiar colores
En `tailwind.config.js`, modifica los valores de `navy`, `gold`, `sand` en la sección `colors` para adaptar la paleta de colores a tu gusto.

### ✍️ Cambiar textos
Cada componente tiene los textos directamente en el JSX. Busca y edita los textos que necesites en cada archivo de `/src/components/`.

### 💬 Personalizar mensaje de WhatsApp
Cambia el texto del link en `src/lib/constants.ts`:
```ts
// Cambia el texto después de ?text=
// Usa encodeURIComponent() para caracteres especiales
export const WHATSAPP_LINK = "https://wa.me/52NUMERO?text=Hola%2C%20..."
```

---

## 📱 Funcionalidades incluidas

- ✅ Diseño responsive mobile-first
- ✅ Header fijo con scroll suave
- ✅ Menú hamburguesa para móvil
- ✅ Botón flotante de WhatsApp
- ✅ Todos los CTAs con link a WhatsApp
- ✅ SEO básico con metadata
- ✅ Export estático (sin backend)
- ✅ Paleta de colores: navy, dorado, arena y blanco
- ✅ Tipografía Playfair Display + Lato (Google Fonts)
- ✅ Animaciones y microinteracciones CSS

---

## 🛠️ Stack técnico

| Tecnología | Versión |
|-----------|---------|
| Next.js | 14.2.5 |
| React | 18 |
| Tailwind CSS | 3.4 |
| TypeScript | 5 |
| Google Fonts | Playfair Display + Lato |

---

*Landing desarrollada para Hotel San Ignacio Inn, Torreón, Coahuila, México.*
